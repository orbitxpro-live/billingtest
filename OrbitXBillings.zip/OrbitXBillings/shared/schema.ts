import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Clients table
export const clients = pgTable("clients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyName: text("company_name").notNull(),
  industryId: varchar("industry_id"),
  timezone: text("timezone").default("UTC"),
  currency: text("currency").default("USD"),
  billingEmail: text("billing_email").notNull(),
  billingContactId: varchar("billing_contact_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Billing plans table
export const billingPlans = pgTable("billing_plans", {
  id: varchar("id").primaryKey(), // e.g., Plan_B1000, SUB_2K_VISITORS
  modelType: text("model_type").notNull(), // subscription|pay_per_lead|budget_inclusive|relevant
  displayName: text("display_name").notNull(),
  priceMonthly: decimal("price_monthly", { precision: 10, scale: 2 }),
  includedVisitors: integer("included_visitors"),
  includedLeads: integer("included_leads"),
  includedRelevantConvs: integer("included_relevant_convs"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Client billing state table
export const clientBillingState = pgTable("client_billing_state", {
  clientId: varchar("client_id").primaryKey().references(() => clients.id),
  currentModel: text("current_model").notNull(), // subscription|pay_per_lead|budget_inclusive|relevant
  planId: varchar("plan_id").references(() => billingPlans.id),
  budgetCapAmount: decimal("budget_cap_amount", { precision: 10, scale: 2 }),
  pricePerLead: decimal("price_per_lead", { precision: 10, scale: 2 }),
  customPriceFlag: boolean("custom_price_flag").default(false),
  customPriceAuthorizedBy: varchar("custom_price_authorized_by"),
  priceEffectiveDate: timestamp("price_effective_date"),
  usedVisitorsCount: integer("used_visitors_count").default(0),
  usedLeadsCount: integer("used_leads_count").default(0),
  usedRelevantCount: integer("used_relevant_count").default(0),
  autoDisableFlag: boolean("auto_disable_flag").default(false),
  status: text("status").default("active"), // active|disabled|suspended
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Invoices table
export const invoices = pgTable("invoices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  invoiceId: text("invoice_id").notNull().unique(),
  clientId: varchar("client_id").notNull().references(() => clients.id),
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  items: json("items"),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
  tax: decimal("tax", { precision: 10, scale: 2 }).default("0"),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  paidStatus: text("paid_status").default("unpaid"), // paid|unpaid|pending|overdue
  pdfPath: text("pdf_path"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Audit logs table
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => clients.id),
  userId: varchar("user_id"),
  action: text("action").notNull(),
  data: json("data"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true,
});

export const insertBillingPlanSchema = createInsertSchema(billingPlans).omit({
  createdAt: true,
});

export const insertClientBillingStateSchema = createInsertSchema(clientBillingState).omit({
  updatedAt: true,
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  timestamp: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;
export type InsertBillingPlan = z.infer<typeof insertBillingPlanSchema>;
export type BillingPlan = typeof billingPlans.$inferSelect;
export type InsertClientBillingState = z.infer<typeof insertClientBillingStateSchema>;
export type ClientBillingState = typeof clientBillingState.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
