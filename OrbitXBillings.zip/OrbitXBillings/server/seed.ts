import { db } from "./db";
import { billingPlans, clients, clientBillingState } from "@shared/schema";

export async function seedDatabase() {
  console.log("Seeding database...");

  try {
    // Seed billing plans
    const plans = [
      // Subscription plans
      { id: "SUB_2K_VISITORS", modelType: "subscription", displayName: "2K Visitors", priceMonthly: "99.00", includedVisitors: 2000 },
      { id: "SUB_5K_VISITORS", modelType: "subscription", displayName: "5K Visitors", priceMonthly: "199.00", includedVisitors: 5000 },
      { id: "SUB_10K_PLUS", modelType: "subscription", displayName: "10K+ Visitors", priceMonthly: "399.00", includedVisitors: 10000 },
      
      // Budget inclusive plans
      { id: "Plan_B500", modelType: "budget_inclusive", displayName: "Budget $500", priceMonthly: "500.00", includedLeads: 40 },
      { id: "Plan_B750", modelType: "budget_inclusive", displayName: "Budget $750", priceMonthly: "750.00", includedLeads: 60 },
      { id: "Plan_B1000", modelType: "budget_inclusive", displayName: "Budget $1000", priceMonthly: "1000.00", includedLeads: 80 },
      { id: "Plan_B1500", modelType: "budget_inclusive", displayName: "Budget $1500", priceMonthly: "1500.00", includedLeads: 120 },
      { id: "Plan_B2000", modelType: "budget_inclusive", displayName: "Budget $2000", priceMonthly: "2000.00", includedLeads: 160 },
      
      // Relevant conversation plans
      { id: "RELEVANT_BASIC_20", modelType: "relevant", displayName: "Relevant Basic", priceMonthly: "149.00", includedRelevantConvs: 20 },
      { id: "RELEVANT_STD_40", modelType: "relevant", displayName: "Relevant Standard", priceMonthly: "279.00", includedRelevantConvs: 40 },
      { id: "RELEVANT_ENTERPRISE_CUSTOM", modelType: "relevant", displayName: "Relevant Enterprise", priceMonthly: "499.00", includedRelevantConvs: 100 }
    ];

    for (const plan of plans) {
      await db.insert(billingPlans).values(plan).onConflictDoNothing();
    }

    // Create a demo client
    const [demoClient] = await db.insert(clients).values({
      companyName: "Demo Corp",
      industryId: "technology",
      billingEmail: "billing@democorp.com",
      currency: "USD",
      timezone: "America/New_York"
    }).onConflictDoNothing().returning();

    if (demoClient) {
      // Create billing state for demo client
      await db.insert(clientBillingState).values({
        clientId: demoClient.id,
        currentModel: "budget_inclusive",
        planId: "Plan_B1000",
        usedLeadsCount: 63,
        autoDisableFlag: true,
        status: "active"
      }).onConflictDoNothing();
    }

    console.log("Database seeded successfully");
    return demoClient;
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}