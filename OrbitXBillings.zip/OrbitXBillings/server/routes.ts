import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { seedDatabase } from "./seed";
import { insertClientBillingStateSchema, insertInvoiceSchema, insertAuditLogSchema } from "@shared/schema";
import { z } from "zod";

// WebSocket connection manager
const wsConnections = new Set();

function broadcastUsageUpdate(clientId: string, data: any) {
  const message = JSON.stringify({ type: 'usage_update', clientId, data });
  wsConnections.forEach((ws: any) => {
    if (ws.readyState === 1) { // WebSocket.OPEN
      ws.send(message);
    }
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Seed database on startup
  const demoClient = await seedDatabase();
  const demoClientId = demoClient?.id || "demo-client-id";

  // Get client billing information
  app.get("/api/clients/:id/billing", async (req, res) => {
    try {
      const { id } = req.params;
      
      const client = await storage.getClient(id);
      if (!client) {
        return res.status(404).json({ error: "Client not found" });
      }
      
      const billingState = await storage.getClientBillingState(id);
      const currentPlan = billingState?.planId ? await storage.getBillingPlan(billingState.planId) : null;
      
      res.json({
        client,
        billingState,
        currentPlan
      });
    } catch (error) {
      console.error("Error fetching billing info:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get billing plans by model type
  app.get("/api/billing-plans/:modelType", async (req, res) => {
    try {
      const { modelType } = req.params;
      const plans = await storage.getBillingPlansByModel(modelType);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching billing plans:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Preview billing change
  app.get("/api/clients/:id/billing/preview", async (req, res) => {
    try {
      const { id } = req.params;
      const { targetModel, planId, customPrice } = req.query;
      
      const currentState = await storage.getClientBillingState(id);
      if (!currentState) {
        return res.status(404).json({ error: "Client billing state not found" });
      }
      
      const currentPlan = currentState.planId ? await storage.getBillingPlan(currentState.planId) : null;
      const targetPlan = planId ? await storage.getBillingPlan(planId as string) : null;
      
      // Calculate proration and credits
      let proration = { credit: 0, charge: 0, description: "" };
      
      if (currentPlan && targetModel === "pay_per_lead") {
        const remainingLeads = (currentPlan.includedLeads || 0) - (currentState.usedLeadsCount || 0);
        const impliedValue = currentPlan.priceMonthly ? parseFloat(currentPlan.priceMonthly) / (currentPlan.includedLeads || 1) : 0;
        const creditAmount = remainingLeads * impliedValue;
        
        proration = {
          credit: creditAmount,
          charge: 0,
          description: `Credit of $${creditAmount.toFixed(2)} for ${remainingLeads} unused leads`
        };
      }
      
      res.json({
        currentPlan,
        targetPlan,
        targetModel,
        customPrice: customPrice ? parseFloat(customPrice as string) : null,
        proration,
        effectiveDate: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error generating preview:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Change billing model/plan
  app.post("/api/clients/:id/billing/change", async (req, res) => {
    try {
      const { id } = req.params;
      const { targetModel, planId, customPrice, effectiveDate } = req.body;
      
      const currentState = await storage.getClientBillingState(id);
      if (!currentState) {
        return res.status(404).json({ error: "Client billing state not found" });
      }
      
      // Update billing state
      const updates: any = {
        currentModel: targetModel,
        planId,
        priceEffectiveDate: new Date(effectiveDate || Date.now())
      };
      
      if (customPrice) {
        updates.pricePerLead = customPrice.toString();
        updates.customPriceFlag = true;
        updates.customPriceAuthorizedBy = "system"; // In real app, use authenticated user
      }
      
      const updatedState = await storage.updateClientBillingState(id, updates);
      
      // Create audit log
      await storage.createAuditLog({
        clientId: id,
        userId: "system",
        action: "billing_model_change",
        data: { from: currentState.currentModel, to: targetModel, planId, customPrice }
      });
      
      // Broadcast update via WebSocket
      broadcastUsageUpdate(id, { type: "model_changed", newModel: targetModel });
      
      res.json(updatedState);
    } catch (error) {
      console.error("Error changing billing model:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get client invoices
  app.get("/api/clients/:id/invoices", async (req, res) => {
    try {
      const { id } = req.params;
      const invoices = await storage.getClientInvoices(id);
      res.json(invoices);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Simulate lead acceptance (for demo purposes)
  app.post("/api/clients/:id/leads/accept", async (req, res) => {
    try {
      const { id } = req.params;
      
      const currentState = await storage.getClientBillingState(id);
      if (!currentState) {
        return res.status(404).json({ error: "Client billing state not found" });
      }
      
      // Increment lead count
      const updatedState = await storage.updateClientBillingState(id, {
        usedLeadsCount: (currentState.usedLeadsCount || 0) + 1
      });
      
      // Broadcast real-time update
      broadcastUsageUpdate(id, {
        type: "lead_accepted",
        newCount: updatedState.usedLeadsCount,
        timestamp: new Date().toISOString()
      });
      
      res.json({ success: true, newCount: updatedState.usedLeadsCount });
    } catch (error) {
      console.error("Error accepting lead:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get demo client ID for frontend
  app.get("/api/demo-client", (req, res) => {
    res.json({ clientId: demoClientId });
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    wsConnections.add(ws);
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      wsConnections.delete(ws);
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      wsConnections.delete(ws);
    });
  });

  return httpServer;
}
