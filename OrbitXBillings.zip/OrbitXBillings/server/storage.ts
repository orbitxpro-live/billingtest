import { 
  type User, type InsertUser,
  type Client, type InsertClient,
  type BillingPlan, type InsertBillingPlan,
  type ClientBillingState, type InsertClientBillingState,
  type Invoice, type InsertInvoice,
  type AuditLog, type InsertAuditLog,
  users, clients, billingPlans, clientBillingState, invoices, auditLogs
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Storage interface for billing operations
export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Client operations
  getClient(id: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  
  // Billing plan operations
  getBillingPlan(id: string): Promise<BillingPlan | undefined>;
  getBillingPlansByModel(modelType: string): Promise<BillingPlan[]>;
  createBillingPlan(plan: InsertBillingPlan): Promise<BillingPlan>;
  
  // Client billing state operations
  getClientBillingState(clientId: string): Promise<ClientBillingState | undefined>;
  updateClientBillingState(clientId: string, updates: Partial<ClientBillingState>): Promise<ClientBillingState>;
  createClientBillingState(state: InsertClientBillingState): Promise<ClientBillingState>;
  
  // Invoice operations
  getInvoice(id: string): Promise<Invoice | undefined>;
  getClientInvoices(clientId: string): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoiceStatus(id: string, status: string): Promise<Invoice>;
  
  // Audit log operations
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  getClientAuditLogs(clientId: string): Promise<AuditLog[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Client operations
  async getClient(id: string): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client || undefined;
  }
  
  async createClient(insertClient: InsertClient): Promise<Client> {
    const [client] = await db
      .insert(clients)
      .values(insertClient)
      .returning();
    return client;
  }
  
  // Billing plan operations
  async getBillingPlan(id: string): Promise<BillingPlan | undefined> {
    const [plan] = await db.select().from(billingPlans).where(eq(billingPlans.id, id));
    return plan || undefined;
  }
  
  async getBillingPlansByModel(modelType: string): Promise<BillingPlan[]> {
    return await db.select().from(billingPlans).where(eq(billingPlans.modelType, modelType));
  }
  
  async createBillingPlan(insertPlan: InsertBillingPlan): Promise<BillingPlan> {
    const [plan] = await db
      .insert(billingPlans)
      .values(insertPlan)
      .returning();
    return plan;
  }
  
  // Client billing state operations
  async getClientBillingState(clientId: string): Promise<ClientBillingState | undefined> {
    const [state] = await db.select().from(clientBillingState).where(eq(clientBillingState.clientId, clientId));
    return state || undefined;
  }
  
  async updateClientBillingState(clientId: string, updates: Partial<ClientBillingState>): Promise<ClientBillingState> {
    const [state] = await db
      .update(clientBillingState)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(clientBillingState.clientId, clientId))
      .returning();
    return state;
  }
  
  async createClientBillingState(insertState: InsertClientBillingState): Promise<ClientBillingState> {
    const [state] = await db
      .insert(clientBillingState)
      .values(insertState)
      .returning();
    return state;
  }
  
  // Invoice operations
  async getInvoice(id: string): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id));
    return invoice || undefined;
  }
  
  async getClientInvoices(clientId: string): Promise<Invoice[]> {
    return await db.select().from(invoices).where(eq(invoices.clientId, clientId));
  }
  
  async createInvoice(insertInvoice: InsertInvoice): Promise<Invoice> {
    const [invoice] = await db
      .insert(invoices)
      .values([insertInvoice])
      .returning();
    return invoice;
  }
  
  async updateInvoiceStatus(id: string, status: string): Promise<Invoice> {
    const [invoice] = await db
      .update(invoices)
      .set({ paidStatus: status })
      .where(eq(invoices.id, id))
      .returning();
    return invoice;
  }
  
  // Audit log operations
  async createAuditLog(insertLog: InsertAuditLog): Promise<AuditLog> {
    const [log] = await db
      .insert(auditLogs)
      .values(insertLog)
      .returning();
    return log;
  }
  
  async getClientAuditLogs(clientId: string): Promise<AuditLog[]> {
    return await db.select().from(auditLogs).where(eq(auditLogs.clientId, clientId));
  }
}

export const storage = new DatabaseStorage();
