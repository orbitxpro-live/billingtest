import { PaymentModelSelector } from '../PaymentModelSelector'
import { useState } from 'react'

export default function PaymentModelSelectorExample() {
  const [selectedModel, setSelectedModel] = useState('budget_inclusive')

  const handlePreviewChange = () => {
    console.log('Preview billing impact triggered for model:', selectedModel)
  }

  return (
    <PaymentModelSelector
      selectedModel={selectedModel}
      onModelChange={setSelectedModel}
      onPreviewChange={handlePreviewChange}
    />
  )
}