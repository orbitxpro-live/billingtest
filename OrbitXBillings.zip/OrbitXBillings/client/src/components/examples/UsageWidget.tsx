import { UsageWidget } from '../UsageWidget'
import { useState } from 'react'

export default function UsageWidgetExample() {
  const [autoDisable, setAutoDisable] = useState(true)
  const [threshold, setThreshold] = useState("90")

  // Mock data - TODO: remove mock functionality
  const mockData = {
    type: 'budget_inclusive' as const,
    used: 63,
    included: 80,
    label: "Leads Used",
    unit: "leads"
  }

  const mockEvents = [
    { id: "1", type: "lead", description: "+1 Lead (Sales)", timeAgo: "2m ago" },
    { id: "2", type: "lead", description: "+1 Lead (Marketing)", timeAgo: "5m ago" },
    { id: "3", type: "system", description: "Threshold warning sent", timeAgo: "1h ago" },
    { id: "4", type: "lead", description: "+2 Leads (Sales)", timeAgo: "2h ago" },
    { id: "5", type: "lead", description: "+1 Lead (Support)", timeAgo: "3h ago" }
  ]

  return (
    <div className="w-80">
      <UsageWidget
        data={mockData}
        events={mockEvents}
        autoDisable={autoDisable}
        onAutoDisableChange={setAutoDisable}
        threshold={threshold}
        onThresholdChange={setThreshold}
      />
    </div>
  )
}