import { AddOnFeatures } from '../AddOnFeatures'
import { Sparkles, Globe, MessageCircle, BarChart, Users, Zap } from "lucide-react"

export default function AddOnFeaturesExample() {
  // Mock data - TODO: remove mock functionality
  const mockFeatures = [
    {
      id: "white_label",
      name: "White Label Branding",
      description: "Remove OrbitXPro branding and use your own company branding",
      icon: <Sparkles className="h-4 w-4" />,
      cost: 199,
      costPeriod: 'monthly' as const,
      category: "Branding",
      popular: true
    },
    {
      id: "global_cdn",
      name: "Global CDN",
      description: "Worldwide content delivery for faster loading times",
      icon: <Globe className="h-4 w-4" />,
      cost: 49,
      costPeriod: 'monthly' as const,
      category: "Performance"
    },
    {
      id: "sms_notifications",
      name: "SMS Notifications",
      description: "Send instant SMS alerts for high-priority leads",
      icon: <MessageCircle className="h-4 w-4" />,
      cost: 0.05,
      costPeriod: 'per_use' as const,
      category: "Communication"
    },
    {
      id: "custom_reporting",
      name: "Custom Reporting",
      description: "Build and schedule custom reports with advanced metrics",
      icon: <BarChart className="h-4 w-4" />,
      cost: 79,
      costPeriod: 'monthly' as const,
      category: "Analytics",
      popular: true
    },
    {
      id: "team_collaboration",
      name: "Team Collaboration",
      description: "Share leads and collaborate with team members",
      icon: <Users className="h-4 w-4" />,
      cost: 29,
      costPeriod: 'monthly' as const,
      category: "Collaboration"
    },
    {
      id: "api_access",
      name: "API Access",
      description: "Full REST API access for custom integrations",
      icon: <Zap className="h-4 w-4" />,
      cost: 99,
      costPeriod: 'monthly' as const,
      category: "Integration"
    }
  ]

  const handleEnableFeature = (featureId: string) => {
    console.log('Enable feature:', featureId)
  }

  return (
    <AddOnFeatures
      features={mockFeatures}
      onEnableFeature={handleEnableFeature}
    />
  )
}