import { ActiveSubscription } from '../ActiveSubscription'

export default function ActiveSubscriptionExample() {
  // Mock data - TODO: remove mock functionality
  const mockSubscription = {
    planId: "Plan_B1000",
    planName: "Budget Inclusive $1,000",
    modelType: 'budget_inclusive' as const,
    cycleStart: "2025-01-01",
    cycleEnd: "2025-01-31",
    nextBillingDate: "2025-02-01",
    nextBillingAmount: 1000,
    effectivePrice: 12.50,
    remainingQuota: {
      type: "leads",
      used: 63,
      total: 80,
      unit: "leads"
    }
  }

  const handleChangePlan = () => {
    console.log('Change plan triggered')
  }

  const handlePreviewUsage = () => {
    console.log('Preview usage triggered')
  }

  const handleBillingHistory = () => {
    console.log('Billing history triggered')
  }

  return (
    <ActiveSubscription
      subscription={mockSubscription}
      onChangePlan={handleChangePlan}
      onPreviewUsage={handlePreviewUsage}
      onBillingHistory={handleBillingHistory}
    />
  )
}