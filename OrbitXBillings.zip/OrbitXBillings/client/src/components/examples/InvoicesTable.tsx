import { InvoicesTable } from '../InvoicesTable'

export default function InvoicesTableExample() {
  // Mock data - TODO: remove mock functionality
  const mockInvoices = [
    {
      id: "inv_001",
      number: "INV-2025-001",
      period: {
        start: "2024-12-01",
        end: "2024-12-31"
      },
      date: "2025-01-01",
      type: "Monthly Subscription",
      amount: 1000.00,
      status: 'paid' as const,
      pdfPath: "/invoices/inv_001.pdf"
    },
    {
      id: "inv_002",
      number: "INV-2025-002",
      period: {
        start: "2025-01-01",
        end: "2025-01-31"
      },
      date: "2025-01-15",
      type: "Usage Charges",
      amount: 245.50,
      status: 'pending' as const
    },
    {
      id: "inv_003",
      number: "INV-2024-052",
      period: {
        start: "2024-11-01",
        end: "2024-11-30"
      },
      date: "2024-12-01",
      type: "Monthly Subscription",
      amount: 1000.00,
      status: 'paid' as const,
      pdfPath: "/invoices/inv_003.pdf"
    },
    {
      id: "inv_004",
      number: "INV-2024-051",
      period: {
        start: "2024-10-15",
        end: "2024-10-31"
      },
      date: "2024-11-01",
      type: "Adjustment",
      amount: 125.00,
      status: 'unpaid' as const
    }
  ]

  const handleViewInvoice = (invoiceId: string) => {
    console.log('View invoice:', invoiceId)
  }

  const handleDownloadInvoice = (invoiceId: string) => {
    console.log('Download invoice:', invoiceId)
  }

  const handlePayInvoice = (invoiceId: string) => {
    console.log('Pay invoice:', invoiceId)
  }

  return (
    <InvoicesTable
      invoices={mockInvoices}
      onViewInvoice={handleViewInvoice}
      onDownloadInvoice={handleDownloadInvoice}
      onPayInvoice={handlePayInvoice}
    />
  )
}