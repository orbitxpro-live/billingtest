import { ActiveFeatures } from '../ActiveFeatures'
import { Phone, MapPin, Headphones, Zap, Shield, BarChart3 } from "lucide-react"

export default function ActiveFeaturesExample() {
  // Mock data - TODO: remove mock functionality
  const mockFeatures = [
    {
      id: "call_connect",
      name: "Call Connect",
      description: "Direct phone integration for lead follow-up",
      icon: <Phone className="h-4 w-4" />,
      status: 'active' as const,
      cost: 29,
      costPeriod: 'monthly' as const
    },
    {
      id: "region_tool",
      name: "Region Tool",
      description: "Geographic targeting and analysis",
      icon: <MapPin className="h-4 w-4" />,
      status: 'active' as const,
      cost: 19,
      costPeriod: 'monthly' as const
    },
    {
      id: "priority_support",
      name: "Priority Support",
      description: "24/7 dedicated support channel",
      icon: <Headphones className="h-4 w-4" />,
      status: 'inactive' as const,
      cost: 49,
      costPeriod: 'monthly' as const
    },
    {
      id: "advanced_analytics",
      name: "Advanced Analytics",
      description: "Detailed conversion tracking and insights",
      icon: <BarChart3 className="h-4 w-4" />,
      status: 'active' as const,
      cost: 39,
      costPeriod: 'monthly' as const
    },
    {
      id: "enterprise_security",
      name: "Enterprise Security",
      description: "Advanced security features and compliance",
      icon: <Shield className="h-4 w-4" />,
      status: 'inactive' as const,
      cost: 99,
      costPeriod: 'monthly' as const
    },
    {
      id: "ai_optimization",
      name: "AI Optimization",
      description: "Machine learning lead scoring",
      icon: <Zap className="h-4 w-4" />,
      status: 'active' as const,
      cost: 59,
      costPeriod: 'monthly' as const
    }
  ]

  const handleFeatureToggle = (featureId: string, enabled: boolean) => {
    console.log(`Feature ${featureId} ${enabled ? 'enabled' : 'disabled'}`)
  }

  return (
    <ActiveFeatures
      features={mockFeatures}
      onFeatureToggle={handleFeatureToggle}
    />
  )
}