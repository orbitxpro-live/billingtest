import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Switch } from "@/components/ui/switch"
import { CreditCard, Users, Target, MessageSquare, Check } from "lucide-react"
import { useState } from "react"

interface PaymentModel {
  id: 'subscription' | 'pay_per_lead' | 'budget_inclusive' | 'relevant'
  name: string
  icon: React.ReactNode
  description: string
  isActive: boolean
}

interface PaymentModelSelectorProps {
  selectedModel: string
  onModelChange: (model: string) => void
  onPreviewChange: () => void
}

export function PaymentModelSelector({ selectedModel, onModelChange, onPreviewChange }: PaymentModelSelectorProps) {
  const [subscriptionPlan, setSubscriptionPlan] = useState("SUB_2K_VISITORS")
  const [payPerLeadType, setPayPerLeadType] = useState("unlimited")
  const [budgetPlan, setBudgetPlan] = useState("Plan_B1000")
  const [relevantPlan, setRelevantPlan] = useState("RELEVANT_STD_40")
  const [customPrice, setCustomPrice] = useState("22.49")
  const [autoDisable, setAutoDisable] = useState(true)

  const models: PaymentModel[] = [
    {
      id: 'subscription',
      name: 'Subscription / Usage-Based',
      icon: <Users className="h-5 w-5" />,
      description: 'Fixed monthly fee with visitor quotas',
      isActive: selectedModel === 'subscription'
    },
    {
      id: 'pay_per_lead',
      name: 'Pay-Per-Lead',
      icon: <Target className="h-5 w-5" />,
      description: 'Pay only for qualified leads',
      isActive: selectedModel === 'pay_per_lead'
    },
    {
      id: 'budget_inclusive',
      name: 'Budget-Based Inclusive',
      icon: <CreditCard className="h-5 w-5" />,
      description: 'Fixed budget with included leads',
      isActive: selectedModel === 'budget_inclusive'
    },
    {
      id: 'relevant',
      name: 'Relevant Conversations',
      icon: <MessageSquare className="h-5 w-5" />,
      description: 'Pay for meaningful conversations only',
      isActive: selectedModel === 'relevant'
    }
  ]

  const renderModelConfiguration = () => {
    switch (selectedModel) {
      case 'subscription':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="plan_dropdown_subscription">Plan</Label>
              <Select value={subscriptionPlan} onValueChange={setSubscriptionPlan}>
                <SelectTrigger id="plan_dropdown_subscription" data-testid="select-subscription-plan">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="SUB_2K_VISITORS">2K Visitors - $99/month</SelectItem>
                  <SelectItem value="SUB_5K_VISITORS">5K Visitors - $199/month</SelectItem>
                  <SelectItem value="SUB_10K_PLUS">10K+ Visitors - $399/month</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Switch checked={autoDisable} onCheckedChange={setAutoDisable} data-testid="switch-subscription-auto-disable" />
              <Label>Auto-Disable when quota reached</Label>
            </div>
            <div className="text-sm text-muted-foreground">
              Next billing: Jan 15, 2025
            </div>
          </div>
        )
      
      case 'pay_per_lead':
        return (
          <div className="space-y-4">
            <RadioGroup value={payPerLeadType} onValueChange={setPayPerLeadType}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="unlimited" id="unlimited" />
                <Label htmlFor="unlimited">Unlimited Billing</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="budget_capped" id="budget_capped" />
                <Label htmlFor="budget_capped">Budget-Capped</Label>
              </div>
            </RadioGroup>
            
            {payPerLeadType === 'budget_capped' && (
              <div>
                <Label htmlFor="budget_plan_id">Budget Plan</Label>
                <Select>
                  <SelectTrigger id="budget_plan_id" data-testid="select-budget-plan">
                    <SelectValue placeholder="Select budget limit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="500">$500/month</SelectItem>
                    <SelectItem value="1000">$1,000/month</SelectItem>
                    <SelectItem value="2000">$2,000/month</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div>
              <Label htmlFor="custom_price_input">Price per Lead</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="custom_price_input"
                  type="number"
                  value={customPrice}
                  onChange={(e) => setCustomPrice(e.target.value)}
                  className="w-24"
                  data-testid="input-custom-price"
                />
                <span className="text-sm text-muted-foreground">
                  Industry base: $22.49
                </span>
              </div>
            </div>
          </div>
        )
      
      case 'budget_inclusive':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="plan_dropdown_budget">Budget Plan</Label>
              <Select value={budgetPlan} onValueChange={setBudgetPlan}>
                <SelectTrigger id="plan_dropdown_budget" data-testid="select-budget-inclusive-plan">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Plan_B500">$500 - 40 leads included</SelectItem>
                  <SelectItem value="Plan_B750">$750 - 60 leads included</SelectItem>
                  <SelectItem value="Plan_B1000">$1,000 - 80 leads included</SelectItem>
                  <SelectItem value="Plan_B1500">$1,500 - 120 leads included</SelectItem>
                  <SelectItem value="Plan_B2000">$2,000 - 160 leads included</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="text-sm text-muted-foreground">
              Effective cost: $12.50 per lead
            </div>
            <div className="flex items-center space-x-2">
              <Switch checked={autoDisable} onCheckedChange={setAutoDisable} data-testid="switch-budget-auto-disable" />
              <Label>Auto-Disable when quota reached</Label>
            </div>
          </div>
        )
      
      case 'relevant':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="plan_dropdown_relevant">Plan</Label>
              <Select value={relevantPlan} onValueChange={setRelevantPlan}>
                <SelectTrigger id="plan_dropdown_relevant" data-testid="select-relevant-plan">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="RELEVANT_BASIC_20">Basic - 20 conversations</SelectItem>
                  <SelectItem value="RELEVANT_STD_40">Standard - 40 conversations</SelectItem>
                  <SelectItem value="RELEVANT_ENTERPRISE_CUSTOM">Enterprise - Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="text-sm text-muted-foreground">
              Overage: $7 per additional relevant conversation
            </div>
          </div>
        )
      
      default:
        return null
    }
  }

  return (
    <div id="billing-model-selector" className="space-y-6" data-testid="container-model-selector">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {models.map((model) => (
          <Card 
            key={model.id}
            className={`cursor-pointer transition-all hover-elevate ${model.isActive ? 'ring-2 ring-primary' : ''}`}
            onClick={() => onModelChange(model.id)}
            data-testid={`card-model-${model.id}`}
          >
            <CardHeader className="flex flex-row items-center space-y-0 pb-2">
              <div className="flex items-center space-x-2">
                {model.icon}
                <CardTitle className="text-sm">{model.name}</CardTitle>
              </div>
              {model.isActive && <Check className="h-4 w-4 text-primary ml-auto" />}
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">{model.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedModel && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">
              {models.find(m => m.id === selectedModel)?.name} Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {renderModelConfiguration()}
            
            <div className="flex gap-2 pt-4">
              <Button 
                onClick={onPreviewChange}
                variant="outline"
                data-testid="button-preview-billing"
              >
                Preview Billing Impact
              </Button>
              <Button 
                id="apply_change_btn"
                data-testid="button-apply-change"
              >
                Confirm & Apply
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}