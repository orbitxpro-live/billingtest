import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Activity, Clock, AlertCircle } from "lucide-react"
import { useState } from "react"

interface UsageData {
  type: 'subscription' | 'pay_per_lead' | 'budget_inclusive' | 'relevant'
  used: number
  included?: number
  budget?: number
  label: string
  unit: string
}

interface UsageEvent {
  id: string
  type: string
  description: string
  timeAgo: string
}

interface UsageWidgetProps {
  data: UsageData
  events: UsageEvent[]
  autoDisable: boolean
  onAutoDisableChange: (enabled: boolean) => void
  threshold: string
  onThresholdChange: (threshold: string) => void
}

export function UsageWidget({
  data,
  events,
  autoDisable,
  onAutoDisableChange,
  threshold,
  onThresholdChange
}: UsageWidgetProps) {
  const [lastUpdate, setLastUpdate] = useState(new Date())

  const getUsagePercentage = () => {
    if (data.type === 'pay_per_lead' && data.budget) {
      return ((data.budget - data.used) / data.budget) * 100
    }
    if (data.included) {
      return (data.used / data.included) * 100
    }
    return 0
  }

  const getProgressColor = () => {
    const percentage = getUsagePercentage()
    if (percentage >= 90) return "bg-destructive"
    if (percentage >= 70) return "bg-orange-500"
    return "bg-chart-2"
  }

  const formatUsageDisplay = () => {
    if (data.type === 'pay_per_lead' && data.budget) {
      return `Budget Balance: $${(data.budget - data.used).toFixed(2)}`
    }
    if (data.included) {
      return `${data.used.toLocaleString()} / ${data.included.toLocaleString()} ${data.unit}`
    }
    return `${data.used.toLocaleString()} ${data.unit} this cycle`
  }

  return (
    <Card id="usage_widget" className="w-full" data-testid="card-usage-widget">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Usage</CardTitle>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          Last update {lastUpdate.toLocaleTimeString()}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">{data.label}</span>
            <Badge variant="outline" className="text-xs">
              {formatUsageDisplay()}
            </Badge>
          </div>
          <Progress 
            value={getUsagePercentage()} 
            className="h-2"
            data-testid="progress-usage"
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Switch 
              checked={autoDisable}
              onCheckedChange={onAutoDisableChange}
              data-testid="switch-auto-disable"
            />
            <span className="text-sm">Auto-Disable</span>
          </div>
          <Select value={threshold} onValueChange={onThresholdChange}>
            <SelectTrigger className="w-20" data-testid="select-threshold">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="75">75%</SelectItem>
              <SelectItem value="90">90%</SelectItem>
              <SelectItem value="95">95%</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Activity className="h-4 w-4" />
            Recent Activity
          </div>
          <div className="space-y-1">
            {events.map((event) => (
              <div key={event.id} className="flex items-center justify-between text-xs" data-testid={`event-${event.id}`}>
                <span className="text-muted-foreground">{event.description}</span>
                <span className="text-muted-foreground">{event.timeAgo}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}