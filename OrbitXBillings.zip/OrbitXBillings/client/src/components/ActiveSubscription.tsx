import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CreditCard, Calendar, DollarSign, Target } from "lucide-react"

interface SubscriptionData {
  planId: string
  planName: string
  modelType: 'subscription' | 'pay_per_lead' | 'budget_inclusive' | 'relevant'
  cycleStart: string
  cycleEnd: string
  nextBillingDate: string
  nextBillingAmount: number
  effectivePrice?: number
  remainingQuota: {
    type: string
    used: number
    total: number
    unit: string
  }
}

interface ActiveSubscriptionProps {
  subscription: SubscriptionData
  onChangePlan: () => void
  onPreviewUsage: () => void
  onBillingHistory: () => void
}

export function ActiveSubscription({ 
  subscription, 
  onChangePlan, 
  onPreviewUsage, 
  onBillingHistory 
}: ActiveSubscriptionProps) {
  const getModelIcon = () => {
    switch (subscription.modelType) {
      case 'subscription':
        return <CreditCard className="h-4 w-4" />
      case 'pay_per_lead':
        return <Target className="h-4 w-4" />
      case 'budget_inclusive':
        return <DollarSign className="h-4 w-4" />
      case 'relevant':
        return <CreditCard className="h-4 w-4" />
      default:
        return <CreditCard className="h-4 w-4" />
    }
  }

  const getModelTypeName = () => {
    switch (subscription.modelType) {
      case 'subscription':
        return 'Subscription'
      case 'pay_per_lead':
        return 'Pay-Per-Lead'
      case 'budget_inclusive':
        return 'Budget-Inclusive'
      case 'relevant':
        return 'Relevant Conversations'
      default:
        return 'Unknown'
    }
  }

  const quotaPercentage = (subscription.remainingQuota.used / subscription.remainingQuota.total) * 100

  return (
    <Card data-testid="card-active-subscription">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getModelIcon()}
            <CardTitle className="text-lg">Active Subscription</CardTitle>
          </div>
          <Badge variant="outline">{getModelTypeName()}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="text-sm font-medium">Plan Details</div>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Plan ID:</span>
                <span className="font-mono" data-testid="text-plan-id">{subscription.planId}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Plan Name:</span>
                <span data-testid="text-plan-name">{subscription.planName}</span>
              </div>
              {subscription.effectivePrice && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Effective Price:</span>
                  <span data-testid="text-effective-price">${subscription.effectivePrice}/lead</span>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-sm font-medium">Billing Cycle</div>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Period:</span>
                <span data-testid="text-billing-period">
                  {new Date(subscription.cycleStart).toLocaleDateString()} - {new Date(subscription.cycleEnd).toLocaleDateString()}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Next Billing:</span>
                <span data-testid="text-next-billing">
                  {new Date(subscription.nextBillingDate).toLocaleDateString()}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Amount:</span>
                <span className="font-semibold" data-testid="text-billing-amount">
                  ${subscription.nextBillingAmount.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Remaining Quota</span>
            <Badge variant={quotaPercentage > 90 ? "destructive" : quotaPercentage > 70 ? "secondary" : "outline"}>
              {subscription.remainingQuota.total - subscription.remainingQuota.used} {subscription.remainingQuota.unit} left
            </Badge>
          </div>
          <div className="text-xs text-muted-foreground">
            {subscription.remainingQuota.used} of {subscription.remainingQuota.total} {subscription.remainingQuota.unit} used
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button 
            variant="outline" 
            onClick={onChangePlan}
            data-testid="button-change-plan"
          >
            Change Plan
          </Button>
          <Button 
            variant="outline" 
            onClick={onPreviewUsage}
            data-testid="button-preview-usage"
          >
            Preview Usage
          </Button>
          <Button 
            variant="outline" 
            onClick={onBillingHistory}
            data-testid="button-billing-history"
          >
            Billing History
          </Button>
        </div>

        <div className="pt-4 border-t">
          <div className="flex items-center space-x-2 text-sm">
            <span className="text-muted-foreground">Payment Method:</span>
            <span>•••• •••• •••• 1234</span>
            <Button variant="ghost" className="h-auto p-0 text-sm" data-testid="button-change-payment">
              Change
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}