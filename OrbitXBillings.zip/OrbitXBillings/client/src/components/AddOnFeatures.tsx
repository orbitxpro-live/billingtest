import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Plus, Sparkles, Globe, MessageCircle, BarChart, Users, Zap } from "lucide-react"

interface AddOnFeature {
  id: string
  name: string
  description: string
  icon: React.ReactNode
  cost: number
  costPeriod: 'monthly' | 'per_use' | 'one_time'
  category: string
  popular?: boolean
}

interface AddOnFeaturesProps {
  features: AddOnFeature[]
  onEnableFeature: (featureId: string) => void
}

export function AddOnFeatures({ features, onEnableFeature }: AddOnFeaturesProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Analytics':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
      case 'Communication':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
      case 'Integration':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'
      case 'Automation':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300'
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
    }
  }

  return (
    <Card data-testid="card-addon-features">
      <CardHeader>
        <CardTitle>Available Add-On Features</CardTitle>
        <p className="text-sm text-muted-foreground">
          Enhance your OrbitXPro experience with these additional features
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((feature) => (
            <Card 
              key={feature.id} 
              className="relative p-4 hover-elevate transition-all"
              data-testid={`addon-card-${feature.id}`}
            >
              {feature.popular && (
                <Badge className="absolute -top-2 -right-2 bg-primary text-primary-foreground">
                  Popular
                </Badge>
              )}
              
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    {feature.icon}
                    <div>
                      <h4 className="font-medium text-sm">{feature.name}</h4>
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${getCategoryColor(feature.category)}`}
                      >
                        {feature.category}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                <p className="text-xs text-muted-foreground">
                  {feature.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="text-sm font-semibold">
                    ${feature.cost}
                    <span className="text-xs text-muted-foreground font-normal">
                      /{feature.costPeriod}
                    </span>
                  </div>
                  <Button 
                    size="sm"
                    onClick={() => onEnableFeature(feature.id)}
                    data-testid={`button-enable-addon-${feature.id}`}
                    className="gap-1"
                  >
                    <Plus className="h-3 w-3" />
                    Enable
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        {features.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <Sparkles className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>All available features are already enabled!</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}