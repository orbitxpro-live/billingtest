import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Phone, MapPin, Headphones, Zap, Shield, BarChart3 } from "lucide-react"

interface Feature {
  id: string
  name: string
  description: string
  icon: React.ReactNode
  status: 'active' | 'inactive'
  cost?: number
  costPeriod?: 'monthly' | 'per_use'
}

interface ActiveFeaturesProps {
  features: Feature[]
  onFeatureToggle: (featureId: string, enabled: boolean) => void
}

export function ActiveFeatures({ features, onFeatureToggle }: ActiveFeaturesProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-chart-2 text-white">Active</Badge>
      case 'inactive':
        return <Badge variant="outline">Inactive</Badge>
      default:
        return <Badge variant="secondary">Unknown</Badge>
    }
  }

  const getFeatureIcon = (iconName: string) => {
    switch (iconName) {
      case 'phone':
        return <Phone className="h-4 w-4" />
      case 'map':
        return <MapPin className="h-4 w-4" />
      case 'headphones':
        return <Headphones className="h-4 w-4" />
      case 'zap':
        return <Zap className="h-4 w-4" />
      case 'shield':
        return <Shield className="h-4 w-4" />
      case 'chart':
        return <BarChart3 className="h-4 w-4" />
      default:
        return <Zap className="h-4 w-4" />
    }
  }

  return (
    <Card data-testid="card-active-features">
      <CardHeader>
        <CardTitle>Active Features</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((feature) => (
            <Card key={feature.id} className="p-4" data-testid={`feature-card-${feature.id}`}>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {feature.icon}
                    <span className="font-medium text-sm">{feature.name}</span>
                  </div>
                  {getStatusBadge(feature.status)}
                </div>
                
                <p className="text-xs text-muted-foreground">
                  {feature.description}
                </p>
                
                {feature.cost && (
                  <div className="text-xs text-muted-foreground">
                    ${feature.cost}/{feature.costPeriod}
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <Switch
                    checked={feature.status === 'active'}
                    onCheckedChange={(enabled) => onFeatureToggle(feature.id, enabled)}
                    data-testid={`switch-feature-${feature.id}`}
                  />
                  {feature.status === 'inactive' && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => console.log(`Enable ${feature.name} triggered`)}
                      data-testid={`button-enable-${feature.id}`}
                    >
                      Enable & Charge
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}