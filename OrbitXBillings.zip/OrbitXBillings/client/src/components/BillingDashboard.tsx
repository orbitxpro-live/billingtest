import { useState, useEffect } from "react"
import { UsageWidget } from "./UsageWidget"
import { PaymentModelSelector } from "./PaymentModelSelector"
import { ActiveSubscription } from "./ActiveSubscription"
import { ActiveFeatures } from "./ActiveFeatures"
import { InvoicesTable } from "./InvoicesTable"
import { AddOnFeatures } from "./AddOnFeatures"
import { useBillingData, useDemoClient, useInvoices, useAcceptLead } from "@/hooks/useBillingData"
import { useWebSocket } from "@/hooks/useWebSocket"
import { Button } from "@/components/ui/button"
import { Phone, MapPin, Headphones, Zap, Shield, BarChart3 } from "lucide-react"

export function BillingDashboard() {
  const [selectedModel, setSelectedModel] = useState('budget_inclusive')
  const [autoDisable, setAutoDisable] = useState(true)
  const [threshold, setThreshold] = useState("90")

  // Get demo client ID and real billing data
  const { data: demoClientData } = useDemoClient()
  const clientId = demoClientData?.clientId
  
  const { data: billingData, isLoading: isBillingLoading } = useBillingData(clientId || '')
  const { data: invoicesData } = useInvoices(clientId || '')
  const acceptLeadMutation = useAcceptLead()
  
  // Set up WebSocket connection for real-time updates
  useWebSocket(clientId)
  
  // Update selected model based on current billing state
  useEffect(() => {
    if (billingData?.billingState?.currentModel) {
      setSelectedModel(billingData.billingState.currentModel)
    }
    if (billingData?.billingState?.autoDisableFlag !== undefined) {
      setAutoDisable(billingData.billingState.autoDisableFlag)
    }
  }, [billingData])
  
  if (isBillingLoading || !clientId) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    )
  }

  // Transform real data for components
  const usageData = {
    type: billingData?.billingState?.currentModel as any || 'budget_inclusive',
    used: billingData?.billingState?.usedLeadsCount || 0,
    included: billingData?.currentPlan?.includedLeads || 0,
    budget: billingData?.currentPlan?.priceMonthly ? parseFloat(billingData.currentPlan.priceMonthly) : 0,
    label: getUsageLabel(billingData?.billingState?.currentModel),
    unit: getUsageUnit(billingData?.billingState?.currentModel)
  }

  const usageEvents = [
    { id: "1", type: "lead", description: "+1 Lead (Sales)", timeAgo: "2m ago" },
    { id: "2", type: "lead", description: "+1 Lead (Marketing)", timeAgo: "5m ago" },
    { id: "3", type: "system", description: "Auto-threshold check", timeAgo: "15m ago" },
    { id: "4", type: "lead", description: "+2 Leads (Sales)", timeAgo: "1h ago" },
    { id: "5", type: "system", description: "Usage report generated", timeAgo: "2h ago" }
  ]

  const subscriptionData = {
    planId: billingData?.currentPlan?.id || "Plan_B1000",
    planName: billingData?.currentPlan?.displayName || "Budget Inclusive Plan",
    modelType: billingData?.billingState?.currentModel as any || 'budget_inclusive',
    cycleStart: "2025-01-01",
    cycleEnd: "2025-01-31",
    nextBillingDate: "2025-02-01",
    nextBillingAmount: billingData?.currentPlan?.priceMonthly ? parseFloat(billingData.currentPlan.priceMonthly) : 1000,
    effectivePrice: billingData?.currentPlan?.priceMonthly && billingData?.currentPlan?.includedLeads ? 
      parseFloat(billingData.currentPlan.priceMonthly) / billingData.currentPlan.includedLeads : 12.50,
    remainingQuota: {
      type: "leads",
      used: billingData?.billingState?.usedLeadsCount || 0,
      total: billingData?.currentPlan?.includedLeads || 80,
      unit: "leads"
    }
  }

  const activeFeatures = [
    {
      id: "call_connect",
      name: "Call Connect",
      description: "Direct phone integration for lead follow-up",
      icon: <Phone className="h-4 w-4" />,
      status: 'active' as const,
      cost: 29,
      costPeriod: 'monthly' as const
    },
    {
      id: "region_tool",
      name: "Region Tool",
      description: "Geographic targeting and analysis",
      icon: <MapPin className="h-4 w-4" />,
      status: 'active' as const,
      cost: 19,
      costPeriod: 'monthly' as const
    },
    {
      id: "priority_support",
      name: "Priority Support",
      description: "24/7 dedicated support channel",
      icon: <Headphones className="h-4 w-4" />,
      status: 'inactive' as const,
      cost: 49,
      costPeriod: 'monthly' as const
    },
    {
      id: "advanced_analytics",
      name: "Advanced Analytics",
      description: "Detailed conversion tracking and insights",
      icon: <BarChart3 className="h-4 w-4" />,
      status: 'active' as const,
      cost: 39,
      costPeriod: 'monthly' as const
    }
  ]

  const invoices = invoicesData || []

  const addOnFeatures = [
    {
      id: "white_label",
      name: "White Label Branding",
      description: "Remove OrbitXPro branding and use your own company branding",
      icon: <Zap className="h-4 w-4" />,
      cost: 199,
      costPeriod: 'monthly' as const,
      category: "Branding",
      popular: true
    }
  ]

  const handlePreviewChange = () => {
    console.log('Preview billing impact triggered for model:', selectedModel)
  }
  
  const handleSimulateLead = () => {
    if (clientId) {
      acceptLeadMutation.mutate(clientId)
    }
  }

  const handleFeatureToggle = (featureId: string, enabled: boolean) => {
    console.log(`Feature ${featureId} ${enabled ? 'enabled' : 'disabled'}`)
  }

  const handleViewInvoice = (invoiceId: string) => {
    console.log('View invoice:', invoiceId)
  }

  const handleDownloadInvoice = (invoiceId: string) => {
    console.log('Download invoice:', invoiceId)
  }

  const handlePayInvoice = (invoiceId: string) => {
    console.log('Pay invoice:', invoiceId)
  }

  const handleEnableAddOn = (featureId: string) => {
    console.log('Enable add-on:', featureId)
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
          <span>Dashboard</span>
          <span>/</span>
          <span>Billing</span>
        </div>
        <h1 className="text-3xl font-bold">Billing & Plans</h1>
      </div>

      {/* Demo Controls */}
      <div className="mb-4 p-4 bg-muted/50 rounded-lg border">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium">Demo Mode</h3>
            <p className="text-sm text-muted-foreground">
              Try the real-time features - current usage: {usageData.used}/{usageData.included} {usageData.unit}
            </p>
          </div>
          <Button 
            onClick={handleSimulateLead}
            disabled={acceptLeadMutation.isPending}
            variant="outline"
          >
            {acceptLeadMutation.isPending ? 'Processing...' : 'Simulate +1 Lead'}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Column - Payment Models */}
        <div className="lg:col-span-3 space-y-6">
          <PaymentModelSelector
            selectedModel={selectedModel}
            onModelChange={setSelectedModel}
            onPreviewChange={handlePreviewChange}
          />

          <ActiveSubscription
            subscription={subscriptionData}
            onChangePlan={() => console.log('Change plan triggered')}
            onPreviewUsage={() => console.log('Preview usage triggered')}
            onBillingHistory={() => console.log('Billing history triggered')}
          />

          <ActiveFeatures
            features={activeFeatures}
            onFeatureToggle={handleFeatureToggle}
          />

          <InvoicesTable
            invoices={invoices}
            onViewInvoice={handleViewInvoice}
            onDownloadInvoice={handleDownloadInvoice}
            onPayInvoice={handlePayInvoice}
          />

          <AddOnFeatures
            features={addOnFeatures}
            onEnableFeature={handleEnableAddOn}
          />
        </div>

        {/* Right Column - Usage Widget */}
        <div className="lg:col-span-1">
          <div className="sticky top-4">
            <UsageWidget
              data={usageData}
              events={usageEvents}
              autoDisable={autoDisable}
              onAutoDisableChange={setAutoDisable}
              threshold={threshold}
              onThresholdChange={setThreshold}
            />
          </div>
        </div>
      </div>
    </div>
  )

  function getUsageLabel(modelType?: string) {
    switch (modelType) {
      case 'subscription': return 'Visitors Used'
      case 'pay_per_lead': return 'Leads This Cycle'
      case 'budget_inclusive': return 'Leads Used'
      case 'relevant': return 'Relevant Conversations'
      default: return 'Usage'
    }
  }

  function getUsageUnit(modelType?: string) {
    switch (modelType) {
      case 'subscription': return 'visitors'
      case 'pay_per_lead': return 'leads'
      case 'budget_inclusive': return 'leads'
      case 'relevant': return 'conversations'
      default: return 'units'
    }
  }
}