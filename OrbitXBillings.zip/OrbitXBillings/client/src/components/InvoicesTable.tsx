import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Eye, Download, CreditCard } from "lucide-react"
import { useState } from "react"

interface Invoice {
  id: string
  number: string
  period: {
    start: string
    end: string
  }
  date: string
  type: string
  amount: number
  status: 'paid' | 'unpaid' | 'pending' | 'overdue'
  pdfPath?: string
}

interface InvoicesTableProps {
  invoices: Invoice[]
  onViewInvoice: (invoiceId: string) => void
  onDownloadInvoice: (invoiceId: string) => void
  onPayInvoice: (invoiceId: string) => void
}

export function InvoicesTable({ 
  invoices, 
  onViewInvoice, 
  onDownloadInvoice, 
  onPayInvoice 
}: InvoicesTableProps) {
  const [filter, setFilter] = useState("all")

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-chart-2 text-white">Paid</Badge>
      case 'unpaid':
        return <Badge variant="destructive">Unpaid</Badge>
      case 'pending':
        return <Badge variant="secondary">Pending</Badge>
      case 'overdue':
        return <Badge variant="destructive">Overdue</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const filteredInvoices = invoices.filter(invoice => {
    if (filter === "all") return true
    return invoice.status === filter
  })

  return (
    <Card id="invoice_table" data-testid="card-invoices-table">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Invoices</CardTitle>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-32" data-testid="select-invoice-filter">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="unpaid">Unpaid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Period</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInvoices.map((invoice) => (
              <TableRow key={invoice.id} data-testid={`row-invoice-${invoice.id}`}>
                <TableCell className="font-mono text-sm">
                  {invoice.number}
                </TableCell>
                <TableCell className="text-sm">
                  {new Date(invoice.period.start).toLocaleDateString()} - {new Date(invoice.period.end).toLocaleDateString()}
                </TableCell>
                <TableCell className="text-sm">
                  {new Date(invoice.date).toLocaleDateString()}
                </TableCell>
                <TableCell className="text-sm">
                  {invoice.type}
                </TableCell>
                <TableCell className="text-sm font-semibold">
                  ${invoice.amount.toFixed(2)}
                </TableCell>
                <TableCell>
                  {getStatusBadge(invoice.status)}
                </TableCell>
                <TableCell>
                  <div className="flex space-x-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => onViewInvoice(invoice.id)}
                      data-testid={`invoice_view_btn_${invoice.id}`}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => onDownloadInvoice(invoice.id)}
                      data-testid={`invoice_download_btn_${invoice.id}`}
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    {(invoice.status === 'unpaid' || invoice.status === 'overdue') && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => onPayInvoice(invoice.id)}
                        data-testid={`invoice_pay_btn_${invoice.id}`}
                      >
                        <CreditCard className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        
        {filteredInvoices.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            No invoices found for the selected filter.
          </div>
        )}
      </CardContent>
    </Card>
  )
}