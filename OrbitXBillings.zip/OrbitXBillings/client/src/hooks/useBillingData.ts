import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export interface BillingState {
  client: {
    id: string;
    companyName: string;
    billingEmail: string;
    currency: string;
  };
  billingState: {
    clientId: string;
    currentModel: string;
    planId?: string;
    usedLeadsCount?: number;
    usedVisitorsCount?: number;
    usedRelevantCount?: number;
    autoDisableFlag: boolean;
    status: string;
  };
  currentPlan?: {
    id: string;
    displayName: string;
    priceMonthly: string;
    includedLeads?: number;
    includedVisitors?: number;
    includedRelevantConvs?: number;
  };
}

export function useBillingData(clientId: string) {
  return useQuery({
    queryKey: ['billing', clientId],
    queryFn: async (): Promise<BillingState> => {
      const response = await apiRequest('GET', `/api/clients/${clientId}/billing`);
      return response.json();
    },
    refetchInterval: 30000, // Refetch every 30 seconds as fallback
  });
}

export function useBillingPlans(modelType: string) {
  return useQuery({
    queryKey: ['billing-plans', modelType],
    queryFn: async () => {
      const response = await apiRequest('GET', `/api/billing-plans/${modelType}`);
      return response.json();
    },
  });
}

export function useBillingPreview(clientId: string, targetModel: string, planId?: string, customPrice?: number) {
  return useQuery({
    queryKey: ['billing-preview', clientId, targetModel, planId, customPrice],
    queryFn: async () => {
      const params = new URLSearchParams({
        targetModel,
        ...(planId && { planId }),
        ...(customPrice && { customPrice: customPrice.toString() }),
      });
      const response = await apiRequest('GET', `/api/clients/${clientId}/billing/preview?${params}`);
      return response.json();
    },
    enabled: !!targetModel,
  });
}

export function useChangeBillingModel() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ clientId, targetModel, planId, customPrice, effectiveDate }: {
      clientId: string;
      targetModel: string;
      planId?: string;
      customPrice?: number;
      effectiveDate?: string;
    }) => {
      const response = await apiRequest('POST', `/api/clients/${clientId}/billing/change`, {
        targetModel,
        planId,
        customPrice,
        effectiveDate,
      });
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Invalidate and refetch billing data
      queryClient.invalidateQueries({ queryKey: ['billing', variables.clientId] });
    },
  });
}

export function useInvoices(clientId: string) {
  return useQuery({
    queryKey: ['invoices', clientId],
    queryFn: async () => {
      const response = await apiRequest('GET', `/api/clients/${clientId}/invoices`);
      return response.json();
    },
  });
}

export function useAcceptLead() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (clientId: string) => {
      const response = await apiRequest('POST', `/api/clients/${clientId}/leads/accept`);
      return response.json();
    },
    onSuccess: (data, clientId) => {
      // Invalidate and refetch billing data to update counts
      queryClient.invalidateQueries({ queryKey: ['billing', clientId] });
    },
  });
}

export function useDemoClient() {
  return useQuery({
    queryKey: ['demo-client'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/demo-client');
      return response.json();
    },
  });
}