import { BillingDashboard } from "@/components/BillingDashboard"

export default function BillingPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <BillingDashboard />
    </div>
  )
}